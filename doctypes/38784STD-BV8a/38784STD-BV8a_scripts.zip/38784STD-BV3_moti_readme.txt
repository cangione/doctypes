38784STD-BV3_moti_readme.txt

This script will produce a specific instance based the contents of a master 
document and the use of marked sections.  Additional details can be found
on the TMSS Web page, Main Menu, titled "Multiple Output Options Tagging
Technique".  

	
From the command line, type: 38784STD-BV3_moti.sh master.instance.sgml specific.instance.sgml

	where:	38784STD-BV3_moti.sh is the name of the script, 
		master.instance.sgml is the input file, and
		specific.instance.sgml is the desired name of the output file.
		
This script actually will extract the "specific" data needed for a specific
instance based on the marked sections chosen - using either include or 
ignore.

The final output represents your instance file with only the specific data
required.  To ensure data integrity, it is advised that you maintain your 
original instance at all times.  It is also suggested that you select a 
unique filename every time this scrip is executed.  The script will
create that filename every time and if two books are developed in one directory
with the same filename the output files will be overwritten.  




	*************************************************************************
	*
	*
	*  	FOR ANY PROBLEMS OR QUESTIONS WITH THE EXECUTION OF
	*	THESE SCRIPTS PROGRAMS, PLEASE CONTACT:
	*
	*		BARBARA JONES
	*		Programmer/Analyst
	*		AF IDE PROGRAM OFFICE
	*
	*************************************************************************




SCRIPT:		38784STD-BV3_moti.sh

ADDITIONAL SCRIPTS:	parsenosyn
		
PROGRAMS:	38784STD-BV3_normal_moti.xom
		



