38784STD-BV8 Reference Designator Index

The Reference Designator Index is a sorted list of part numbers and their associated
figure and refdes numbers used in the Illustrated Parts Breakdown Chapter 
tables in 38784STD-BV8.  OmniMark will automatically generate this list 
using data tagged throughout the manual.  It is assumed that your system 
administrator has installed OmniMark on your system and that all scripts 
and programs have been copied onto your system and modified to fit your 
specific site environment.

No additional tagging is necessary to produce this list.  All that is 
required by the author is to insert the start tag for reference designator index with
the attribute of autobuild="1".  For example:

	<rfdsindx autobuild="1">
	
There are three options for the reference designator index.  All are 
controlled by an attribute on this element.  This attribute - TYPE -
will determine whether the index is by reference designator number, 
SSSN number or both.  Tag this element with the desired output.

DO NOT include the end tag for rfdsindx or the tag rfdsgrp. Both will
	be generated and placed by the OmniMark program.

1.	For the option of an index using the refdes element:
	
	From the command line, type:

		38784STD-BV8_refdes.sh filename.ext
	
	where:	38784STD-BV8_refdes.sh is the name of the script, and
		filename.ext is the name of the instance you want to process
		
2.	For the option of an index using the sssn element:
	
	From the command line, type:

		38784STD-BV8_sssn.sh filename.ext
	
	where:	38784STD-BV8_sssn.sh is the name of the script, and
		filename.ext is the name of the instance you want to process

		
3.	For the option of an index using both refdes and SSSN elements:
	
	From the command line, type:

		38784STD-BV8_refdes_sssn.sh filename.ext
	
	where:	38784STD-BV8_refdes_sssn.sh is the name of the script, and
		filename.ext is the name of the instance you want to process
		
		
These scripts will call two programs needed to produce the index.  The
first pulls all numbers and tags from the ipb chapter in 
the instance and sorts them in numerical order. The second program places
the sorted list within the refdes tags.  Again, this is done
automatically, with no author effort.  

The final output of the program is a file called:  refdes_final.sgml, sssn_final.sgml,
or refdes_sssn_final.sgml  which represents your instance file with a new index.
This file can now be renamed or used as an input to compose using DLcomposer.
To ensure data integrity, it is advised that you maintain your original 
instance at all times.



	*************************************************************************
	*
	*
	*  	FOR ANY PROBLEMS OR QUESTIONS WITH THE EXECUTION OF
	*	THESE SCRIPTS PROGRAMS, PLEASE CONTACT:
	*
	*		TOM PATTERSON
	*		AF DFSG/SBO
	*		thomas.patterson@wpafb.af.mil
	*
	*
	*************************************************************************






SCRIPT NAME:	38784STD-BV8_refdes.sh

PROGRAMS:	38784STD-BV8_refdes1.xom
		38784STD-BV8_refdes2.xom

		
SCRIPT NAME:	38784STD-BV8_sssn.sh

PROGRAMS:	38784STD-BV8_sssn1.xom
		38784STD-BV4_sssn2.xom

		
SCRIPT NAME:	38784STD-BV8_refdes_sssn.sh

PROGRAMS:	38784STD-BV8_refdes_sssn1.xom
		38784STD-BV8_refdes2.xom
		
